sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "../model/formatter",
    "sap/ui/core/Fragment",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], function (BaseController, JSONModel, formatter, Fragment, Filter, FilterOperator) {
    "use strict";

    return BaseController.extend("dcgrprocess.controller.Worklist", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

        /**
         * Called when the worklist controller is instantiated.
         * @public
         */
        onInit : function () {
            var oViewModel;

            // keeps the search state
            this._aTableSearchState = [];
            // Model used to manipulate control states
            oViewModel = new JSONModel({
                worklistTableTitle : this.getResourceBundle().getText("worklistTableTitle"),
                shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
                shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
                tableNoDataText : this.getResourceBundle().getText("tableNoDataText")
            });
            this.setModel(oViewModel, "worklistView");

        },

        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

        /**
         * Triggered by the table's 'updateFinished' event: after new table
         * data is available, this handler method updates the table counter.
         * This should only happen if the update was successful, which is
         * why this handler is attached to 'updateFinished' and not to the
         * table's list binding's 'dataReceived' method.
         * @param {sap.ui.base.Event} oEvent the update finished event
         * @public
         */
        onUpdateFinished : function (oEvent) {
            // update the worklist's object counter after the table update
            var sTitle,
                oTable = oEvent.getSource(),
                iTotalItems = oEvent.getParameter("total");
            // only update the counter if the length is final and
            // the table is not empty
            if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
                sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
            } else {
                sTitle = this.getResourceBundle().getText("worklistTableTitle");
            }
            this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
        },

        /**
         * Event handler when a table item gets pressed
         * @param {sap.ui.base.Event} oEvent the table selectionChange event
         * @public
         */
        onPress : function (oEvent) {
            // The source is the list item that got pressed
            this._showObject(oEvent.getSource());
        },
        // Define a formatter function to set the text and state of the ObjectStatus
        formatStatus: function(sStatus) {
            debugger;
            var oStatus = {
            text: "dddd",
            //state: "None"
            };
  
            switch (sStatus) {
                case "S":
                    oStatus.text = "Success";
                    //oStatus.state = "Success";
                    break;
                case "F":
                    oStatus.text = "Fail";
                    //oStatus.state = "Warning";
                    break;
                case "E":
                    oStatus.text = "Empty";
                    //oStatus.state = "Error";
                    break;
                case "I":
                    oStatus.text = "Information";
                    //oStatus.state = "Error";
                    break;
                default:
                    oStatus.text = "None";
            }
        return oStatus;
    },
    formatStatusText: function(sStatus) {
        switch (sStatus) {
          case "F":
            return "Neu";
          case "S":
            return "Abgeschlossen";
          case "I":
            return "Bearbeitet";
          case "E":
            return "Keine Produkt";
          default:
            return "None";
        }
      },
      
      formatStatusState: function(sStatus) {
        switch (sStatus) {
          case "F":
            return "Information";
          case "S":
            return "Success";
          case "I":
            return "Warning";
          case "E":
            return "Error";
          default:
            return "None";
        }
      },
      formatIconText: function(sStatus) {
        switch (sStatus) {
          case "F":
            return "sap-icon://information";
          case "S":
            return "sap-icon://sys-enter-2";
          case "I":
            return "sap-icon://alert";
          case "E":
            return "sap-icon://error";
          default:
            return "None";
        }
      },
        onValueHelpRequest: function (oEvent) {
			var sInputValue = oEvent.getSource().getValue(),
				oView = this.getView();

			if (!this._pValueHelpDialog) {
				this._pValueHelpDialog = Fragment.load({
					id: oView.getId(),
					name: "dcgrprocess.fragments.Supplier",
					controller: this
				}).then(function (oDialog) {
					oView.addDependent(oDialog);
					return oDialog;
				});
			}
			this._pValueHelpDialog.then(function (oDialog) {
				// Create a filter for the binding
				oDialog.getBinding("items").filter([new Filter("Vbeln", FilterOperator.Contains, sInputValue)]);
				// Open ValueHelpDialog filtered by the input's value
				oDialog.open(sInputValue);
			});
		},
        onValueHelpDialogSearch: function (oEvent) {
            alert("naber2");
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Vbeln", FilterOperator.Contains, sValue);
			oEvent.getSource().getBinding("items").filter([oFilter]);
		},
		onValueHelpDialogClose: function (oEvent) {
            alert("naber3");
			var sDescription,
				oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);
			if (!oSelectedItem) {
				return;
			}
			sDescription = oSelectedItem.getDescription();
			this.byId("productInput").setSelectedKey(sDescription);
			this.byId("selectedKeyIndicator").setText(sDescription);
		},
        onSuggestionItemSelected: function (oEvent) {
            alert("naber4");
			var oItem = oEvent.getParameter("selectedItem");
			var oText = oItem ? oItem.getKey() : "";
			this.byId("selectedKeyIndicator").setText(oText);
		},
        /**
         * Event handler for navigating back.
         * Navigate back in the browser history
         * @public
         */
        onNavBack : function() {
            // eslint-disable-next-line sap-no-history-manipulation
            history.go(-1);
        },
        f4HelpForLieferant: function() {
            if (this.Lifnr) {
                this.Lifnr = sap.ui.xmlfragment("dcgrprocess.webapp.fragments.Supplier", this);
                this.getView().addDependent(this.Lifnr);
            }
            this.Lifnr.open();
        },
        onSearch : function (oEvent) {
            //if (oEvent.getParameters().refreshButtonPressed) {
                // Search field's 'refresh' button has been pressed.
                // This is visible if you select any main list item.
                // In this case no new search is triggered, we only
                // refresh the list binding.
                //this.onRefresh();
            //} else {
              //  var aTableSearchState = [];
              //  var sQuery = oEvent.getParameter("query");

              //  if (sQuery && sQuery.length > 0) {
              //      aTableSearchState = [new Filter("Vbeln", FilterOperator.Contains, sQuery)];
              //  }
               // this._applySearch(aTableSearchState);
            //}
            var sSearchValue = oEvent.getSource().getValue();
            var oTable = this.getView().byId("table");
            var oBinding = oTable.getBinding("items");
            var oFilter = new sap.ui.model.Filter({
                filters: [
                    new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.Contains, sSearchValue),
                    new sap.ui.model.Filter("Lifnrtext", sap.ui.model.FilterOperator.Contains, sSearchValue)
                ],
                and: false
            });
            if (sSearchValue) {
                oBinding.filter(oFilter);
            } else {
                oBinding.filter([]);
            }
        },

        /**
         * Event handler for refresh event. Keeps filter, sort
         * and group settings and refreshes the list binding.
         * @public
         */
        onRefresh : function () {
            var oTable = this.byId("table");
            oTable.getBinding("items").refresh();
        },

        /* =========================================================== */
        /* internal methods                                            */
        /* =========================================================== */

        /**
         * Shows the selected item on the object page
         * @param {sap.m.ObjectListItem} oItem selected Item
         * @private
         */
        _showObject : function (oItem) {
            this.getRouter().navTo("object", {
                objectId: oItem.getBindingContext().getPath().substring("/ZET_GROBWESet".length)
            });
        },
        formatDate: function(value) {
            var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "yyyy-MM-dd"});
            return oDateFormat.format(new Date(value));
        },
        /**
         * Internal helper method to apply both filter and search state together on the list binding
         * @param {sap.ui.model.Filter[]} aTableSearchState An array of filters for the search
         * @private
         */
        _applySearch: function(aTableSearchState) {
            var oTable = this.byId("table"),
                oViewModel = this.getModel("worklistView");
            oTable.getBinding("items").filter(aTableSearchState, "Application");
            // changes the noDataText of the list in case there are no filter results
            if (aTableSearchState.length !== 0) {
                oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
            }
        }

    });
});
