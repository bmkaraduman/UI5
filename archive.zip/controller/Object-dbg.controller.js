var countTry = 3;
var isEqualAllListWithSap = false;
var gl_status = "";

sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
    "../model/formatter"
], function (BaseController, JSONModel, History, formatter) {
    "use strict";

    return BaseController.extend("dcgrprocess.controller.Object", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

        /**
         * Called when the worklist controller is instantiated.
         * @public
         */
        onInit : function () {
            // Model used to manipulate control states. The chosen values make sure,
            // detail page shows busy indication immediately so there is no break in
            // between the busy indication for loading the view's meta data
            var oViewModel = new JSONModel({
                    busy : true,
                    delay : 0
                });
            this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
            this.setModel(oViewModel, "objectView");
            var oTable = this.getView().byId("tblArticleList");
            oTable.attachEvent("change", this.onChange, this);

        },
        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */


        /**
         * Event handler  for navigating back.
         * It there is a history entry we go one step back in the browser history
         * If not, it will replace the current entry of the browser history with the worklist route.
         * @public
         */
        onNavBack : function() {
            var sPreviousHash = History.getInstance().getPreviousHash();
            if (sPreviousHash !== undefined) {
                // eslint-disable-next-line sap-no-history-manipulation
                history.go(-1);
            } else {
                this.getRouter().navTo("worklist", {}, true);
            }
        },

        /* =========================================================== */
        /* internal methods                                            */
        /* =========================================================== */

        /**
         * Binds the view to the object path.
         * @function
         * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
         * @private
         */
        _onObjectMatched : function (oEvent) {
            var sObjectId =  oEvent.getParameter("arguments").objectId;
            this._bindView("/ZET_GROBWESet" + sObjectId);
        },
        onAfterShow: function() {
            debugger;
            // Code to be executed after the page has been shown
            // This method is called every time the page is shown, either for the first time or when navigating back to it
        },
        onAfterRendering: function() {
            var table = this.getView().byId("tblArticleList");
            var items = table.getItems();
            // Code to be executed after the page has been shown
            // This method is called every time the page is shown, either for the first time or when navigating back to it
        },
      

        /**
         * Binds the view to the object path.
         * @function
         * @param {string} sObjectPath path to the object to be bound
         * @private
         */
        _bindView : function (sObjectPath) {
            var oViewModel = this.getModel("objectView");
            
            this.getView().bindElement({
                path: sObjectPath,
                events: {
                    change: this._onBindingChange.bind(this),
                    dataRequested: function () {
                        oViewModel.setProperty("/busy", true);
                    },
                    dataReceived: function () {
                        oViewModel.setProperty("/busy", false);
                    }
                }
            });
        },

        _onBindingChange : function () {
            var oView = this.getView(),
                oViewModel = this.getModel("objectView"),
                oElementBinding = oView.getElementBinding();
            
            // No data for the binding
            if (!oElementBinding.getBoundContext()) {
                this.getRouter().getTargets().display("objectNotFound");
                return;
            }
            var oResourceBundle = this.getResourceBundle(),
                oObject = oView.getBindingContext().getObject(),
                sObjectId = oObject.Vbeln,
                sObjectName = oObject.ZET_GROBWESet;
                gl_status =  oObject.Status;

                oViewModel.setProperty("/busy", false);
                oViewModel.setProperty("/shareSendEmailSubject",
                    oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
                oViewModel.setProperty("/shareSendEmailMessage",
                    oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
        },
        onUpdateFinished: function() {
            countTry = 3;
            var table = this.getView().byId("tblArticleList");
            var items = table.getItems();
            var buttonCheck = this.byId("btnCheck");

            if(gl_status === 'S') {
                
                buttonCheck.setEnabled(false);
                // Get the button by its ID
                var oStatus = this.getView().byId("idOStatus");
                // Change the text of the button
                oStatus.setText("Erledigt");
                oStatus.setState("Success");
            }
            else
            {
                buttonCheck.setText("Prüfen (3)");
                buttonCheck.setEnabled(true);
                // Get the button by its ID
                var oStatus = this.getView().byId("idOStatus");
                // Change the text of the button
                oStatus.setText("Ausstehend");
                oStatus.setState("Warning");
            }
                for (var i = 0; i < items.length; i++) {
                    var item = items[i];
                    var oNumberCell = item.getCells()[4];
                    var oValue = item.getCells()[3].getText();
                    debugger;
                    if(item.getCells()[7].getText() === '') {
                        oNumberCell.setEnabled(true);
                        oNumberCell.setValue("");

                        item.getCells()[6].setText("Nicht Eingegeben");
                        item.getCells()[6].setIcon("sap-icon://in-progress");
                        item.getCells()[6].setState("Warning");
                    }
                    else {
                        oNumberCell.setValue(oValue);
                        oNumberCell.setEnabled(false);
    
                        item.getCells()[6].setText("OK");
                        item.getCells()[6].setIcon("sap-icon://sys-enter-2");
                        item.getCells()[6].setState("Success");
                    }
                };
        },
        onAddItemPress: function() {

            var table = this.getView().byId("tblArticleList");
            var items = table.getItems();
            var checkNumberWithSap = true;
            var buttonCheck = this.byId("btnCheck");
            var oStatus = this.getView().byId("idOStatus");
            debugger;
            if (countTry === 0)
            {
                debugger;
                var odataObject = this.getView().getModel();
                var bindingContext = this.getView().getBindingContext();
                var object = bindingContext.getObject();
                var arrayCalc = [];

                for (var i = 0; i < items.length; i++) {
                var item = items[i];
                var inputValue = "0";
                if (item.getCells()[4].getValue() !== '') {
                    inputValue = item.getCells()[4].getValue();    
                }
                
                arrayCalc.push(inputValue);
                item.getCells()[4].setEnabled(false);
                }

                //Take data current table
                var oTable = this.getView().byId("tblArticleList");
                var oBinding = oTable.getBinding("items");
                var aColumns = ["Posnr", "Lfimg", "Vbeln", "Matnr", "SapMatnr"];
                var aChildEntities = [];

                oBinding.getCurrentContexts().forEach(function(oContext, iIndex) {
                    var oObject = oContext.getObject();
                    var oChildEntity = {};
                    aColumns.forEach(function(sColumn) {
                    if(sColumn === "Lfimg") {
                        oChildEntity[sColumn] = arrayCalc[iIndex];
                    } else 
                    {
                        oChildEntity[sColumn] = oObject[sColumn];
                    }
                });
                aChildEntities.push(oChildEntity);
            });

            var articleEntities =  {
                        Vbeln: object.Vbeln,
                        header_to_item: aChildEntities
                    };

            odataObject.create("/ZET_GROBWESet", articleEntities, {
                success: function(){
                    alert("Successfully added");
                    buttonCheck.setEnabled(false);
                     // Change the text of the button
                    oStatus.setText("Erledigt");
                    oStatus.setState("Success");
                },
                alert: function() {
                    alert("Some error");
                },
                bUseBatch: true,
                bDeepCreate: true
            });
            }
            else {
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                var hiddenValue = parseFloat(item.getCells()[3].getText());
                var inputValue = parseFloat(item.getCells()[4].getValue());
                
                if (inputValue === "" || isNaN(inputValue)) {
                    item.getCells()[6].setText("Keine Daten eingegeben");
                    item.getCells()[6].setIcon("sap-icon://alert");
                    item.getCells()[6].setState("Warning");
                    checkNumberWithSap = false;
                }
                else if (hiddenValue !== inputValue) {
                    item.getCells()[6].setText("Überprüfen");
                    item.getCells()[6].setIcon("sap-icon://error");
                    item.getCells()[6].setState("Error");
                    checkNumberWithSap = false;
                }
                else {
                    item.getCells()[6].setText("OK");
                    item.getCells()[6].setIcon("sap-icon://sys-enter-2");
                    item.getCells()[6].setState("Success");
                }
            }

            isEqualAllListWithSap = checkNumberWithSap;
            countTry = countTry - 1;
            if (countTry === 0) 
            {
                //buttonCheck.setEnabled(false);
                buttonCheck.setText("Speichern");
            }
            else
            {
                buttonCheck.setText("Prüfen (" + countTry + ")");
            }
        }
         },

         formatDate: function(value) {
            var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "yyyy-MM-dd"});
            return oDateFormat.format(new Date(value));
        },
    });

});
